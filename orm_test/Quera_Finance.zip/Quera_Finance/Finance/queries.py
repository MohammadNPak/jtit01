from django.db.models import F, Sum, Count, Case, When
from .models import *


def query_0():
    q = Employee.objects.all()
    return q


def query_1():
    # TODO
    pass


def query_2(x):
    # TODO
    pass


def query_3():
    # TODO
    pass


def query_4(x):
    # TODO
    pass


def query_5(x):
    # TODO
    pass


def query_6():
    # TODO
    pass


def query_7():
    # TODO
    pass


def query_8():
    # TODO
    pass


def query_9(x):
    # TODO
    pass


def query_10():
    # TODO
    pass
